<?php
$con = mysqli_connect("localhost","root","","voting_system");

if ($con){
   // echo" connection pass";
    
    
}

?>